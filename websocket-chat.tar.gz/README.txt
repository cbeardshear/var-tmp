java -Dgrails.env=prod -jar websocket-chat-0.1.war

http://localhost:8080/chat

Open a couple of browser tabs and enter messages at the bottom.  Make sure each tab starts at /chat so that they all have a unique session
